package lectures.part1basics

object Expressions extends App {

  val x = 1 + 3 //expression
  println(x)


//  NO WHILE LOOPS!
  def whileLoop(cond : =>Boolean, block : =>Unit) : Unit =
    if(cond) {
      block
      whileLoop(cond, block)
    }


}
