package lectures.part1basics

object ValuesVariablesTypes extends App {
  println("Scala Playground again")

  val ff: Float = 2.0F


}
