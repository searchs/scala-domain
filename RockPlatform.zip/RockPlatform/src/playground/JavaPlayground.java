package playground;

public class JavaPlayground {
    public static void main(String[] args) {
        System.out.println("Java Playground!");
    }
}
