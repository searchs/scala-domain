package udemy
//import akka.actor.Actor
import akka.actor.Actor

class FirstActor extends App{

  def receive = {
    case _ =>
  }

}
