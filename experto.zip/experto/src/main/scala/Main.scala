
object Main {

    def main(args: Array[String]): Unit = {
        // showNames();
        println("Trying to use package object")
    }
}