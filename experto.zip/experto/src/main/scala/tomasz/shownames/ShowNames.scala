package tomasz

package object  ShowNames {


    val names = List("Mikael", "John", "Tommy")
    def displayNames(): Unit = {
        println(names)
    }
}