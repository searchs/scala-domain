package tomasz
import org.scalatest.FunSuite
import scala.util.Try
import scala.util.Success
import scala.util.Failure

class IterationsAndExceptions extends FunSuite {

  test("should use simple try-catch style") {
    try {
      actionThatThrows()
    } catch {
      case e: Exception => e.printStackTrace()
      case _: Throwable => println("other exception")
    }
  }

  // TRY in Functional Style
  test("should use Try in functional style") {
    val action = Try(actionThatThrows())

    action match {
      case Success(_) => println("Success")
      case Failure(e) => println("Failed: " + e.getMessage)
    }

  }

  def actionThatThrows(): Unit = throw new Exception("some message")

}
