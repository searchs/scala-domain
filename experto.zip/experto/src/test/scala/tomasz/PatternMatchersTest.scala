package tomasz
import org.scalatest.FunSuite

class PatternMatchersTest extends FunSuite {

  test("should use pattern matching with case class") {
    // given
    val a: Message = AMessage("some text")
    val b: Message = BMessage(100)

// when
    val resA = matchMessage(a)
    val resB = matchMessage(b)

// then
    assert(resA == "SOME TEXT")
    assert(resB == 1000)

  }

  test("should use scala conditionals") {
// given

    val res = max(1, 20)

// then
    assert(res == 20)

  }

  private def matchMessage(msg: Message): Any = msg match {

    case AMessage(text)  => text.toUpperCase
    case BMessage(price) => price * 10
  }

  abstract class Message

  case class AMessage(text: String) extends Message

  case class BMessage(price: Int) extends Message

  def max(a: Int, b: Int): Int = if (a > b) a else b

}
